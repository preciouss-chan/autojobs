// shared/config.js
// Update this URL to your hosted backend
export const BACKEND_URL = "https://your-backend-domain.com";


